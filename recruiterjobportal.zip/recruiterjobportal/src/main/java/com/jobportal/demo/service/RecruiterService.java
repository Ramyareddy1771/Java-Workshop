package com.jobportal.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobportal.demo.entity.Recruiter;
import com.jobportal.demo.repository.RecruiterRepository;
@Service
public class RecruiterService {

	@Autowired
	RecruiterRepository recruiterrepo;
	public void saveRecruiter (Recruiter rc)
	{
		recruiterrepo.save(rc);
	}

}
